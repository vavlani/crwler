import unittest
from src import crwler

class TestCrwler(unittest.TestCase):
    def test_something(self):
        # Your test cases for crwler.py
        pass

if __name__ == '__main__':
    unittest.main()
