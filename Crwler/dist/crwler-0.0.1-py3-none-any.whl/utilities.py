from urllib.parse import urljoin

def get_absolute_url(base_url, link):
    """Resolve a possibly relative URL to an absolute URL."""
    return urljoin(base_url, link)
